# AGENTS.md — Testing Studio (`TSTD`)

Read the root `AGENTS.md` first. This file adds module-specific rules.

- Spec: `docs/specs/29-testing-studio.md` · Tasks: `docs/tasks/TSTD/INDEX.md` (`python scripts/tasks.py list --module TSTD`)
- Work only inside `admin_utils/teststudio/` and `frontend/src/features/teststudio/`; cross-module needs go through published service interfaces.
- Layering: `api/` (auth + validation only) -> `services/` -> `core/compat` -> Frappe. No `@frappe.whitelist` in `services/`.
- Every endpoint uses the central `guard()` (role + feature flag + rate limit) and the standard response envelope.
- Every mutating action writes an audit row. Strings go through i18n (EN + AR); CSS uses logical properties (RTL).
- Feature flag: `enable_teststudio`.

## Conventions and commands

_Agents: keep this section current. Record commands that work, naming rules, and mistakes to avoid._
