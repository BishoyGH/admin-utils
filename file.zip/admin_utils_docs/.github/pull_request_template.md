## Task(s)
<!-- IDs, e.g. PERM-016 -->

## What and why

## Checklist
- [ ] Title starts with the task ID(s); contract unchanged or change request linked
- [ ] Tests added, green on v15 and v16; LTR + RTL screenshots (UI)
- [ ] guard(), envelope, audit rows, i18n (EN + AR)
- [ ] Task acceptance criteria checked; status updated (`python scripts/tasks.py set-status ID in-review`)
- [ ] Privileged module? Design approval and security-reviewer sign-off linked
